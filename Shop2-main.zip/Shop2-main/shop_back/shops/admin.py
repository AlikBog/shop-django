from django.contrib import admin
from .models import Category
from .models import Tovar

admin.site.register(Category)
admin.site.register(Tovar)
# Register your models here.
