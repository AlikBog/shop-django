<template>
    <v-container>
        <div>
            <h1>О нас</h1>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos, facere, accusantium omnis assumenda placeat aliquid velit expedita ducimus magnam voluptate deserunt cumque, sint laborum aut ut labore perspiciatis dicta recusandae.
            Laborum commodi at reiciendis culpa, fugiat sed nihil eos minima laboriosam iusto sint necessitatibus eligendi, exercitationem, ducimus cupiditate voluptatem adipisci voluptatibus! Et doloribus obcaecati temporibus optio distinctio cum rem nisi.
            Deserunt in rem veritatis sit nam corporis tenetur voluptatibus officia cupiditate magnam et totam amet quam fugit, reprehenderit sint aut nostrum fugiat accusamus, autem suscipit eveniet? Voluptates nesciunt cum in?
            <br>
            Neque nemo consequuntur esse obcaecati tenetur necessitatibus incidunt magni est veniam labore laborum quae, libero voluptatem at quaerat accusamus, enim commodi voluptatibus ex nam aliquam. Eaque similique quaerat repudiandae quam.
            Neque aut, ea ipsa qui molestiae quidem eius maiores debitis, in iusto nemo commodi obcaecati earum, est dolore? Error quam beatae cumque sapiente incidunt dolor unde nemo vitae placeat corporis?
            <br>
            Distinctio ipsa provident aliquam repellendus error iure labore ad, eligendi placeat corporis, eos perferendis nulla quia sequi earum, dolor consequuntur! Officia, accusantium eaque cumque repudiandae ducimus laudantium esse? Explicabo, cumque!
            Dolorum expedita vitae soluta dolor nobis incidunt perspiciatis, similique ratione culpa a unde facere quidem veniam nulla libero eveniet quod aperiam ab aliquam aliquid quo! Quas totam quam asperiores illo.
            <br>
            Quam, explicabo. Mollitia labore nam nulla adipisci delectus eveniet? Officia fugit beatae modi optio dolorum hic quis! Libero ipsa magni corrupti repudiandae! Quasi, temporibus quis blanditiis dicta iste tenetur exercitationem?
            Error aperiam ad modi et consequuntur. Debitis voluptatem quidem dignissimos quasi neque iure! Maiores est beatae quisquam blanditiis aliquam fuga alias corporis illum consectetur ratione veniam doloribus, quis ullam voluptatem!
            <br>
            Corporis odit nobis facilis dolorem, maxime provident modi? Ipsam veritatis illum impedit maiores doloremque delectus laudantium obcaecati vel. Ad ipsam necessitatibus reprehenderit quidem nobis dicta modi odit, doloribus numquam corrupti.
        </div>

    </v-container>
   
</template>

<script setup>

</script>

<style  scoped>

div{
    width: 70%;
    margin: auto;
    
}
h1{
    text-align: center;
}

</style>